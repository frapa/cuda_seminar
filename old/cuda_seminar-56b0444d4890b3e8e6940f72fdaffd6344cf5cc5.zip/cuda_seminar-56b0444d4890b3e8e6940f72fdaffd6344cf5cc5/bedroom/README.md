
Parete:
10px isolante 255/2
30px mattone 255
inframezzato con aria 255/10
vetro finestre 255 * 0.7

bedroom.png = conductivity + heating
