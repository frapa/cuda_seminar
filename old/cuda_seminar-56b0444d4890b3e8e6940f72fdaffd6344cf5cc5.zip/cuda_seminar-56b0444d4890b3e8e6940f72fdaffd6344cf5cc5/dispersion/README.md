Heat Dispersion:
heat is concentrated in the middle of a uniform room and then spread.
Should be a 1D problem, useful to check if our code works fine.

* Dispersion: 255/2 uniform
* Temperature: circle in the center of the room (256 x 256) px
	with radius 50px
